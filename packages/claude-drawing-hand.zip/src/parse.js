// Finds [[image: prompt | option | option]] tags in text.
// v0.4.0 adds engine: perchance | pollinations | horde (the site that draws the image).
// v0.5.0 adds strength: <0-1> (how much an edit of a ref: picture may change it).
// Options (v0.3.4 adds ref: <https url> | blur: <0-1> for a reference image): portrait | landscape | square | WxH (e.g. 512x768) | no: <negative prompt> | seed: <int> | guidance: <1-30> | x4 (or count: 4), 1-8 images
(function (root) {
  const TAG_RE = /\[\[\s*image\s*:\s*([\s\S]*?)\]\]/gi;
  const SIZES = { square: "512x512", portrait: "512x768", landscape: "768x512" };
  // v0.4.0: engine names and their short forms
  const ENGINES = { perchance: "perchance", pollinations: "pollinations", pollination: "pollinations", polli: "pollinations",
    horde: "horde", aihorde: "horde", "ai-horde": "horde", stablehorde: "horde" };

  function parseTag(body, defaults) {
    defaults = defaults || {};
    const parts = body.split("|").map((s) => s.trim()).filter(Boolean);
    const spec = {
      prompt: parts.shift() || "",
      negative: defaults.negative || "",
      resolution: defaults.resolution || "512x512",
      count: Math.min(8, Math.max(1, parseInt(defaults.count, 10) || 1)),
    };
    for (const p of parts) {
      const lower = p.toLowerCase();
      if (SIZES[lower]) spec.resolution = SIZES[lower];
      else if (/^\d{3,4}\s*x\s*\d{3,4}$/.test(lower)) spec.resolution = lower.replace(/\s/g, "");
      else if (/^(no|negative)\s*:/.test(lower)) spec.negative = p.replace(/^[^:]*:\s*/, "");
      else if (/^(x\s*\d+|\d+\s*x|count\s*:\s*\d+|images?\s*:\s*\d+)$/.test(lower))
        spec.count = Math.min(8, Math.max(1, parseInt(lower.match(/\d+/)[0], 10)));
      else if (/^seed\s*:\s*-?\d+$/.test(lower)) spec.seed = parseInt(lower.split(":")[1], 10);
      else if (/^(guidance|guidancescale|cfg)\s*:\s*\d+(\.\d+)?$/.test(lower))
        spec.guidance = Math.min(30, Math.max(1, parseFloat(lower.split(":")[1])));
      // v0.3.4: reference image (Perchance plugin's referenceImage; may be switched off on Perchance's side)
      else if (/^(ref|reference|refimage)\s*:\s*https:\/\/\S+$/i.test(p)) spec.ref = p.replace(/^[^:]*:\s*/, "");
      else if (/^blur\s*:\s*\d*(\.\d+)?$/.test(lower) && lower.split(":")[1].trim())
        spec.blur = Math.min(1, Math.max(0, parseFloat(lower.split(":")[1])));
      // v0.5.0: how far an edit may move away from the reference picture (AI Horde's denoising strength)
      else if (/^(strength|change)\s*:\s*\d*(\.\d+)?$/.test(lower) && lower.split(":")[1].trim())
        spec.strength = Math.min(1, Math.max(0, parseFloat(lower.split(":")[1])));
      // v0.4.0: which engine draws it
      else if (/^(engine|via|using)\s*:\s*\S+$/.test(lower) && ENGINES[lower.split(":")[1].trim()]) spec.engine = ENGINES[lower.split(":")[1].trim()];
      else spec.prompt += ", " + p; // unknown segment: treat as more prompt
    }
    return spec;
  }

  function findTags(text, defaults) {
    const out = [];
    TAG_RE.lastIndex = 0;
    let m;
    while ((m = TAG_RE.exec(text))) {
      const spec = parseTag(m[1], defaults);
      // if (spec.prompt) out.push({ start: m.index, end: m.index + m[0].length, raw: m[0], spec }); // before v0.2.3
      // v0.2.3: skip near-empty prompts ("prompt", "...") that make Perchance draw random images.
      const words = (spec.prompt.match(/[A-Za-z\u00C0-\uFFFF]{2,}/g) || []).length;
      if (spec.prompt && words >= (defaults && defaults.minWords || 0))
        out.push({ start: m.index, end: m.index + m[0].length, raw: m[0], spec });
    }
    return out;
  }

  const api = { findTags, parseTag, SIZES, ENGINES };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.ClaudePerchanceParse = api;
})(typeof self !== "undefined" ? self : this);
